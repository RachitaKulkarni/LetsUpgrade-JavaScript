function ChangeImage1(){
    //console.log("Working");
    const doggy = document.getElementsByClassName("dog");
    console.log(doggy[0]);
    doggy[0].src = "https://i.pinimg.com/474x/45/5a/66/455a6690eec3cbe73223145e8d9b7f33.jpg";
}
function ChangeImage2(){
    //console.log("Working");
    const doggy = document.getElementsByClassName("dog");
    console.log(doggy[0]);
    doggy[0].src = "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/dog-puppy-on-garden-royalty-free-image-1586966191.jpg?crop=0.752xw:1.00xh;0.175xw,0&resize=640:*";
}

function ChangeImage3(){
    //console.log("Working");
    const doggy = document.getElementsByClassName("dog");
    console.log(doggy[0]);
    doggy[0].src = "https://hips.hearstapps.com/ghk.h-cdn.co/assets/17/40/bichon-frise.jpg?crop=1.0xw:1xh;center,top&resize=480:*";
}