/* 
A. Write a function to display all the objects having age less than 30
B. Write a function to display all the objects having country India */

let Details = [
    {
        name : "John",
        age : 25,
        country : "US",
        hobbies : ["Swimming","Cooking"]
    },
    {
        name : "Antony",
        age : 20,
        country : "Brazil",
        hobbies : ["Singing","Dancing","Swimming"]
    },
    {
        name : "Ram",
        age : 40,
        country : "India",
        hobbies : ["Reading","Dancing","Cooking"]
    },
    {
        name : "Mihir",
        age : 48,
        country : "India",
        hobbies : ["Singing","Swimming"]
    },

];


function findAge(){
    console.log("Objects having age less than 30");
    for(let i=0; i<4; i++){
        const ages = Details[i].age;
        if(ages < 30){
        console.log(Details[i]);
        } 
    } 
}
findAge();

function findCountry(){
    console.log("Objects having Country India");
    for(let i=0; i<4; i++){
        const countries = Details[i].country;
        if(countries == "India"){
        console.log(Details[i]);
        } 
    } 
}
findCountry();

