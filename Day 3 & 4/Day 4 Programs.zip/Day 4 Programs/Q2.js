function CopyName(){
    //console.log("Working");
    const names = document.getElementsByClassName("inputText");
    console.log(names[0].value);
    names[1].value = names[0].value;
}