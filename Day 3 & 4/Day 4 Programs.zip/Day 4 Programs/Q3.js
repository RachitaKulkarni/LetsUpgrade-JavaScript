/* Create an array of objects with objects having the following properties
A. {name (string), age (number), country (string), hobbies array (string [ ] ) }
B. Write a function to display all the objects on the console */

let Details = [
    {
        name : "John",
        age : 25,
        country : "US",
        hobbies : ["Swimming","Cooking"]
    },
    {
        name : "Antony",
        age : 20,
        country : "Brazil",
        hobbies : ["Singing","Dancing","Swimming"]
    },
    {
        name : "Ram",
        age : 40,
        country : "India",
        hobbies : ["Reading","Dancing","Cooking"]
    },
    {
        name : "Mihir",
        age : 48,
        country : "India",
        hobbies : ["Singing","Swimming"]
    },

];

for(let i=0; i<4; i++){
    console.log(Details[i]);
}